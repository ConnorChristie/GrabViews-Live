<?php
/**
 * @file		defaultSection.php 	Define the default section for the 'tools' module
 *~TERABYTE_DOC_READY~
 * $Copyright: (c) 2001 - 2011 Invision Power Services, Inc.$
 * $License: http://www.invisionpower.com/company/standards.php#license$
 * $Author: bfarber $
 * @since		20th February 2002
 * $LastChangedDate: 2011-08-05 20:51:01 -0400 (Fri, 05 Aug 2011) $
 * @version		v3.4.5
 * $Revision: 9373 $
 */

$DEFAULT_SECTION = 'licensekey';
