<?php

$DEFAULT_SECTION = 'advice';

//